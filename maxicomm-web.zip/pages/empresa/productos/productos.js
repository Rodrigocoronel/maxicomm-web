$( function() {
	$( "#tabs" ).tabs();
} );
